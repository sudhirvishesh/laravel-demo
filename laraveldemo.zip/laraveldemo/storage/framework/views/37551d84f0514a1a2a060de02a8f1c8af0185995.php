

<?php $__env->startSection('content'); ?>

<div class="content-wrapper px-4 py-2">
	<div class="content-header">
		<h1 class="text-dark">Service Providers Application</h1>
    </div>

    <div class="content px-2">
    <div class="row">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title"> Table</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" >
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>User</th>
                      <th>Email</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $service_providers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($service_provider->id); ?></td>
                      <td><?php echo e($service_provider->name); ?></td>
                      <td><?php echo e($service_provider->email); ?></td>
                      <td> <?php echo e($service_provider->status == 1 ? 'Pending' : ($service_provider->status == 2 ? 'Approved' : 'Rejected')); ?></td>
                      <td> <a href="<?php echo e(route('admin.service-provider.show', ['key'=> $service_provider->id])); ?>"> View Application </a> </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="5">No Rows Found</td>
                    </tr>
                  <?php endif; ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraveldemo\resources\views/admin/service_providers/list.blade.php ENDPATH**/ ?>