<!DOCTYPE html>
<html lang="en">  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Layout | AdminLTE 3 Documentation</title>
    <!-- Begin Jekyll SEO tag v2.5.0 -->
<title>Layout | AdminLTE v3 Documentaion</title>
<meta name="generator" content="Jekyll v3.8.5" />
<meta property="og:title" content="Layout" />
<meta property="og:locale" content="en_US" />
<meta name="description" content="AdminLTE v3 Documentaion" />
<meta property="og:description" content="AdminLTE v3 Documentaion" />
<meta property="og:site_name" content="AdminLTE v3 Documentaion" />
<script type="application/ld+json">
{"description":"AdminLTE v3 Documentaion","@type":"WebPage","url":"/docs/3.0/layout.html","headline":"Layout","@context":"http://schema.org"}</script>
<!-- End Jekyll SEO tag -->

    <link rel="stylesheet" href="<?php echo e(asset('css/admin-lte.css')); ?>">
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed">
    <div class="wrapper">  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
     
    </ul>

    <ul class="navbar-nav ml-auto">
      <!-- <li class="nav-item d-none d-sm-inline-block">
        <a href="index3.html" class="nav-link">Home</a>
      </li> -->
    </ul>

  
    </nav>
  
  <?php echo $__env->make('admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('content'); ?>

    <footer class="main-footer">
      <div class="float-right d-none d-sm-inline">
        v3.0.3
      </div>
      <strong>Copyright &copy; 2014-2020 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
    </footer>
</div>
 
  <script src="<?php echo e(asset('js/admin-lte.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/admin.blade.php ENDPATH**/ ?>