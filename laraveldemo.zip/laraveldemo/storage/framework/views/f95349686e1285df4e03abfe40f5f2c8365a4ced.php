

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    
                    <form action="<?php echo e(url('service-provider/places/add')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="text" name="search_term" id="search_term" >
                        <button class="btn btn-success">Submit</button>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
</div>

<script>

function activatePlacesSearch() {
    var options = {
        types: ['(cities)'],
        componentRestrictions: {country: "us"}
    };
    var input = document.getElementById('search_term');
    var autocomplete = new google.maps.places.Autocomplete(input, options);

    var geocoder = new google.maps.Geocoder();

        geocoder.geocode({ 'address': input.value }, function (results, status) {

            if (status == google.maps.GeocoderStatus.OK) {
                var latitude = results[0].geometry.location.lat();
                var longitude = results[0].geometry.location.lng();
                console.log(longitude+","+latitude);

            }
        });
}
</script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBvOyp2yb3AAj6AOhelF6GiG52wkVfFGeQ&libraries=places&callback=activatePlacesSearch"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/service_provider/places/add-edit.blade.php ENDPATH**/ ?>