

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in! <br>
                    
                    <a href="<?php echo e(route('service-provider.places.add')); ?>">Add City</a>

                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>City</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $serving_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($city->id); ?></td>
                                <td><?php echo e($city->city); ?></td>
                                <td><a class="btn btn-sm btn-danger delete" href="<?php echo e(route('service-provider.places.delete', ['key' => $city->id])); ?>">Delete</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <form id="delete-from" action="" method="POST">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
    (function($) {
            'use strict';
            $(document).on('click', '.delete', function (e) {
                e.preventDefault();
                 if (confirm('Are you sure you want to Delete?')) {
                   $('#delete-from').attr('action', $(this).attr('href')).submit();
                }
                
                
            });
        }(jQuery));
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/service_provider/places/list.blade.php ENDPATH**/ ?>