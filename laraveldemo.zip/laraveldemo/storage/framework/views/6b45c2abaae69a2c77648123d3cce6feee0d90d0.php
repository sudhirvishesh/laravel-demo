

<?php $__env->startSection('content'); ?>

<div class="content-wrapper px-4 py-2">
	<div class="content-header">
		<h1 class="text-dark">Admin Dashboard</h1>
    </div>

    <div class="content px-2">
   Welcome
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraveldemo\resources\views/admin/home.blade.php ENDPATH**/ ?>