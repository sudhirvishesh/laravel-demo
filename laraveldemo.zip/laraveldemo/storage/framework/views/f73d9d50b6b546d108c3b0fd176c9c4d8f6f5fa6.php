<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="" class="brand-link logo-switch">
      <img src="/docs/3.0/assets/img/logo-xs.png" alt="Hidsh Logo" class="brand-image-xl logo-xs">
      <img src="/docs/3.0/assets/img/logo-xl.png" alt="Hidsh Logo Large" class="brand-image-xs logo-xl" style="left: 12px">
    </a>
    <div class="sidebar">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar nav-child-indent flex-column" data-widget="treeview" role="menu">
         
            
            

            <li class="nav-item  ">
              
            <a href=# class="nav-link ">
                <i class="nav-icon fas fa-microchip"></i>
                <p>
                  Services     
                </p>
              </a>
              <a href="<?php echo e(route('admin.service-provider.list')); ?>" class="nav-link ">
                <i class="nav-icon fas fa-microchip"></i>
                <p>
                  Service Provider Applications     
                </p>
              </a>

              
            </li>
         
            
        </ul>
      </nav>
    </div>
  </aside><?php /**PATH C:\xampp\htdocs\blog\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>