<?php
 
namespace App\Traits;
 
trait RouteKey {
    
    public function encodeKey() 
    {
        
    }
    
}