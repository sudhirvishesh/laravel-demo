<?php

namespace App\Models;

use App\Models\Truck;
use App\Models\TripStop;
use Illuminate\Database\Eloquent\Model;

class Trip extends Model
{
    protected $fillable = ['user_id', 'truck_id', 'departure_date', 'arrival_date'];

    public function stops(){
        return $this->hasMany(TripStop::class);
    }

    public function truck()
    {
        return $this->hasOne(Truck::class,"id", "truck_id");
    }

}
