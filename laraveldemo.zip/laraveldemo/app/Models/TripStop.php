<?php

namespace App\Models;

use App\Models\Stop;
use Illuminate\Database\Eloquent\Model;

class TripStop extends Model
{
    protected $fillable = ['trip_id', 'stop_id','sequence_number'];

    public function city(){
        return $this->hasOne(Stop::class,"id","stop_id");
    }

}
