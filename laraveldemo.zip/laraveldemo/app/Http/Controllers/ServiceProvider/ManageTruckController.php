<?php

namespace App\Http\Controllers\ServiceProvider;

use Exception;
use App\Models\Truck;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageTruckController extends Controller
{

    public function rules()
    {
        return [
            'name'   => ['required','max:255'],
            'type'   => ['required','max:255'],
            'weight'     => ['required','max:255'],
            'size'   => ['required','max:255']
        ];
    }

    public function index(){
        $trucks = Truck::where('user_id', auth()->user()->id)->first(); 
        return view('service_provider.trucks.list', compact('trucks'));
    }

    public function add()
    {   
        $truck = optional([]);
        return view('service_provider.trucks.add-edit', compact('truck'));
    }

    public function save(Request $request)
    {
        try {
            
            $request->validate( $this->rules() );
            $data = $request->only('name','type','weight','size');
            $data['user_id'] = auth()->user()->id;
            Truck::create( $data );

            return back()->with([
                'status'    => 'success',
                'messages'  => 'Truck Added Successfully'
            ]);
        } catch (Exception $e) {
            throw_exception($e);
        }
    }

}
