<?php

namespace App\Http\Controllers\ServiceProvider;

use App\Models\Trip;
use App\Models\Stop;
use App\Models\Truck;
use App\Models\TripStop;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TripController extends Controller
{
    public function rules()
    {
        return [
            'truck_id'          => ['required','max:20','integer'],
            'departure_date'    => ['required','date'],
            'arrival_date'      => ['required','date'],
            'start_from'        => ['required','max:20','integer'],
            'destination'       => ['required','max:20','integer']
        ];
    }

    public function index(){
        $trips = Trip::where('user_id', auth()->user()->id)->with('stops.city','truck')->get()
                        ->map( function($trip){
                            $trip->from =  $trip->stops[0]->city->city;
                            $trip->to =  $trip->stops[count($trip->stops)-1]->city->city;
                            $trip->truck_name = $trip->truck->name;
                            return $trip;
                        });
        
        return view('service_provider.trips.list', compact('trips'));
    }

    public function add()
    {       
        $trip = optional([]);
        $cities = Stop::whereUserId(auth()->user()->id)->get();
        $trucks = Truck::whereUserId(auth()->user()->id)->get();

        return view('service_provider.trips.add-edit', compact('trip','cities', 'trucks'));
    }

    public function save(Request $request)
    {
        try {
            
            $request->validate( $this->rules() );
            $trip_data = $request->only('truck_id','departure_date','arrival_date');
            $trip_data['user_id'] = auth()->user()->id;
            $trip = Trip::create( $trip_data );
            $stops = [
                ['trip_id' => $trip->id, 'stop_id' => $request->start_from, 'sequence_number' => 0],
                ['trip_id' => $trip->id, 'stop_id' => $request->destination, 'sequence_number' => 1] 
            ];
            foreach($stops as $stop ){
                TripStop::create($stop);
            }
            return back()->with([
                'status'    => 'success',
                'messages'  => 'Trip Added Successfully'
            ]);
        } catch (Exception $e) {
            throw_exception($e);
        }
    }
}
