<?php

namespace App\Http\Controllers\ServiceProvider;

use App\Models\Stop;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ServingCitiesController extends Controller
{
    
    public function index()
    {
        $serving_cities = Stop::where("user_id",auth()->user()->id)->get();
        return view('service_provider.places.list', compact('serving_cities'));
    }

    public function add()
    {
        return view('service_provider.places.add-edit');
    }

    public function save(Request $request)
    {
        $request->validate([
                'search_term'   => 'required'
            ],
            [
                'search_term.required'  => 'City name is required'
            ]
        );

        try{
            Stop::create([
                'user_id'   => auth()->user()->id,
                'city'      => $request->search_term
            ]);
            return back()->with([
                'status'    => 'success',
                'message'   => __('City added successfully')
            ]);
        } catch(Exception $e) {
            throw_exception($e);
        }

    }

    public function delete($id)
    {
        try{
            $city = Stop::whereId($id)->firstOrFail();
            $city->delete();
            return back()->with([
                'status'    => 'success',
                'message'   => __('City deleted successfully')
            ]);
        } catch(Exception $e) {
            throw_exception($e);
        }
    }

}
