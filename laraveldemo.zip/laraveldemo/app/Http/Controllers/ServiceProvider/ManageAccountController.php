<?php

namespace App\Http\Controllers\ServiceProvider;

use App\User;
use Exception;
use App\Rules\MatchOldPassword;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ManageAccountController extends Controller
{
    
    public function changePassword()
    {
        return view('service_provider.profile.change-password');    
    }

    public function updatePassword(Request $request)
    {
        try {
            $validator = \Validator::make($request->all(), [
                'current_password' => ['required', new MatchOldPassword],
                'new_password' => ['required', 'min:8'],
                'new_confirm_password' => ['same:new_password'],
            ]);

            if ($validator->passes()) {
    
                User::find(auth()->user()->id)->update(['password'=> \Illuminate\Support\Facades\Hash::make($request->new_password)]);
                return response()->json(['success'=>'Password Successfully Updated']);
            }
    
            return response()->json(['error'=> $validator->getMessageBag()->toArray()]);
        } catch(Exception $e) {
            throw_exception($e);
        }
    }

    public function updateName(Request $request)
    {
        try {
            $validator = \Validator::make($request->all(), [
                'name' => ['required']
            ]);

            if ($validator->passes()) {
    
                User::find(auth()->user()->id)->update(['name'=> $request->name]);
                return response()->json(['success'=>'Name Successfully Updated']);
            }
    
            return response()->json(['error'=> $validator->getMessageBag()->toArray()]);
        } catch(Exception $e) {
            throw_exception($e);
        }
    }

}
