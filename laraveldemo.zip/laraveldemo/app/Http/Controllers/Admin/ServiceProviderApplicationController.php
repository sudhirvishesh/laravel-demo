<?php

namespace App\Http\Controllers\Admin;

use App\User;
use App\Jobs\ServiceProviderApplicationStatus;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ServiceProviderApplication;


class ServiceProviderApplicationController extends Controller
{
    public function list()
    {
        $service_providers = ServiceProviderApplication::get();
        return admin_view('service_providers.list', compact('service_providers'));
    }

    public function show($key)
    {
        try{

            $service_provider = ServiceProviderApplication::whereId($key)->firstOrFail();
            return admin_view('service_providers.show', compact('service_provider'));
        } catch(Exception $e) {
            throw_exception($e);
        }
    }

    public function approve(Request $request, $key)
    {
        $request->validate( [
                'email'     => 'exists:users,email'
            ],
            [
                'email.exists'   => 'This account is already approved'
            ]
        );
           
        try{
            $service_provider = ServiceProviderApplication::whereId($key)->firstOrFail();
            User::create([
                'name'      => $service_provider->name,
                'email'     => $service_provider->email,
                'password'  => $service_provider->password,
                'role_id'   => 1,
                'address'   => $service_provider->address
            ]);
            $update = ServiceProviderApplication::whereId($key)->update(['status'=> 2]);
            
            $mail = [
                'name'      => $service_provider->name,
                'email'     => $service_provider->email,
                "subject"   => "Application Approved"    
            ];
            dispatch(new ServiceProviderApplicationStatus($mail));

            return back()->with([
                'status'    => 'success',
                'message'   => __('Application Approved')
            ]);
        } catch(Exception $e) {
            throw_exception($e);
        }
    } 

    public function reject($key)
    {
        try{

            $service_provider = ServiceProviderApplication::whereId($key)->update(['status'=> 3]);
            return back()->with([
                'status'    => 'success',
                'message'   => __('Application Rejected')
            ]);
        } catch(Exception $e) {
            throw_exception($e);
        }
    }
}
