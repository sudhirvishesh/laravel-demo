<?php

namespace App\Http\Controllers\Auth;

use Exception;
use App\Jobs\ServiceProviderApplicationRecieved;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ServiceProviderApplication;

class ServiceProviderApplicationController extends Controller
{
    public function rules()
    {
        return [
            'name'       => ['required', 'string', 'max:255'],
            'email'      => ['required', 'string', 'email', 'max:255', 'unique:service_provider_applications'],
            'password'   => ['required', 'string', 'min:8', 'confirmed'],
            'address'    => ['required', 'string', 'max:255']
        ];
    }
    
    public function index()
    {
        return view('auth.service-provider-application');
    }

    public function store(Request $request)
    {   
        $request->validate( $this->rules() );
        
        try{
            
            $data =  $request->only('name','email','password','address');
            $data['password'] = bcrypt($data['password']);
            ServiceProviderApplication::create($data);
            
            $mail = [
                "name"      => $request->name,
                "email"     => $request->email,
                "subject"   => "Application Recieved"
            ];
            dispatch(new ServiceProviderApplicationRecieved($mail));

            return back()->with([
                'status' => 'success',
                'message' => __('Your application has been received and we will contact you soon by email')
            ]); 
        } catch( Exception $e ) {
            throw $e;
        }
    }
}
