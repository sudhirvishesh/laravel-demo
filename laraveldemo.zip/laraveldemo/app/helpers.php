<?php

use Hashids\Hashids;

if ( ! function_exists('print_a') ) {
    function print_a() {
        $exit = true;
        $args = func_get_args();
        $last = func_get_arg( func_num_args() - 1 );

        if ( is_bool($last) ) {
            array_pop( $args );
            $exit = ($last === true);
        }

        foreach ($args as $arg) {
            print_r('<pre>');
            print_r($arg);
            print_r('</pre>');
        }

        $exit && exit;
    }
}

if ( ! function_exists('throw_exception') ) {
    function throw_exception(Exception $exception) {
        if ( config('app.debug') ) {
            throw $exception;
        } else {
            report($exception);
        }
    }  
}

if ( ! function_exists('auth_user') ) {
    function auth_user(string $attribute = '') {
        $user = Illuminate\Support\Facades\Auth::user();
        return $attribute != '' ? optional($user)->{$attribute} : $user;
    }
}

if ( ! function_exists('auth_admin') ) {
    function auth_admin(string $attribute = '') {
        $user = Illuminate\Support\Facades\Auth::guard('admin')->user();
        return $attribute != '' ? optional($user)->{$attribute} : $user;
    }
}
    
if ( ! function_exists('auth_user_default_route') ) {
    function auth_user_default_route() {
        return 'home';
    }
}

if ( ! function_exists('admin_view') ) {
    function admin_view(string $view_path, array $data = []) {
        return view("admin.{$view_path}", $data);
    }
}

if ( ! function_exists('is_route') ) {
    function is_route(string $route) {
        return Illuminate\Support\Facades\Route::is($route);
    }
}


   