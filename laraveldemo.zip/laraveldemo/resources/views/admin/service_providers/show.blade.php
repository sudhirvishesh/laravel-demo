@extends('layouts.admin')

@section('content')

<div class="content-wrapper px-4 py-2">
	<div class="content-header">
		<h1 class="text-dark">{{ $service_provider->name }}'s Application</h1>
    </div>

    <div class="content px-2">

    @error('email')
        <div class="alert alert-danger" role="alert">
            <h4 class="alert-heading">Alert</h4>
           
                <span>{{ $message }}</span>
           
        </div>
        @enderror
        <form action="{{ route('admin.service-provider.approve', ['key' => $service_provider->id]) }}" method="post" class="form-horizontal">
            @csrf
            <div class="form-group">
                <label for="name">Name</label>
                <input class="form-control" name="email" value="{{ $service_provider->name }}" readonly>
            </div>

            <div class="form-group"> 
                <label for="name">Email</label>
                <input class="form-control" value="{{ $service_provider->email }}" readonly>
            </div>


            <div class="form-group">
                <label for="name">Address</label>
                <input class="form-control" value="{{ $service_provider->address }}" readonly>
            </div>

            <div class="forn-group">
                <button class="btn btn-success">Approve</button>

                <a href="{{ route('admin.service-provider.reject', ['key' => $service_provider->id]) }}" class="btn btn-danger">Reject</a>

            </div>
           


        </form>
    </div>

</div>


@endsection