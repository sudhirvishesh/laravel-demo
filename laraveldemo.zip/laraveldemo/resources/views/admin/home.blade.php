@extends('layouts.admin')

@section('content')

<div class="content-wrapper px-4 py-2">
	<div class="content-header">
		<h1 class="text-dark">Admin Dashboard</h1>
    </div>

    <div class="content px-2">
   Welcome
    </div>
</div>

@endsection