@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <h3>Change Password</h3><br>
                    <form action="{{ url()->current() }}" method="post" class="form-horizonttal">
                        @csrf
                        <div class="form-group">
                            <label for="">Current Password</label>
                            <input type="password" name="current_password" class="form-control">
                            @error('current_password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="">New Password</label>
                            <input type="password" name="new_password" class="form-control">
                            @error('new_password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div class="form-group">
                            <label for="">Confirm Password</label>
                            <input type="password" name="new_confirm_password" class="form-control">
                            @error('new_confirm_password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        
                        <div class="form-group">
                            <button class="btn btn-success">Change Password</button>
                        </div>
                    </form>                
                    
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('styles')

<style>

.invalid-feedback {
    display:block;
}
</style>
@endpush