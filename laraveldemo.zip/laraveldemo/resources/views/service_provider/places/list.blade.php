@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in! <br>
                    
                    <a href="{{ route('service-provider.places.add') }}">Add City</a>

                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>City</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($serving_cities as $city)
                            <tr>
                                <td>{{ $city->id }}</td>
                                <td>{{ $city->city }}</td>
                                <td><a class="btn btn-sm btn-danger delete" href="{{ route('service-provider.places.delete', ['key' => $city->id]) }}">Delete</a></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <form id="delete-from" action="" method="POST">
                        @method('DELETE')
                        @csrf
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')

<script>
    (function($) {
            'use strict';
            $(document).on('click', '.delete', function (e) {
                e.preventDefault();
                 if (confirm('Are you sure you want to Delete?')) {
                   $('#delete-from').attr('action', $(this).attr('href')).submit();
                }
                
                
            });
        }(jQuery));
</script>

@endpush