@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    
                    <form action="{{ url('service-provider/places/add') }}" method="post">
                        @csrf
                        <input type="text" name="search_term" id="search_term" >
                        <button class="btn btn-success">Submit</button>
                    </form>
                   
                </div>
            </div>
        </div>
    </div>
</div>

<script>

function activatePlacesSearch() {
    var options = {
        types: ['(cities)'],
        componentRestrictions: {country: "us"}
    };
    var input = document.getElementById('search_term');
    var autocomplete = new google.maps.places.Autocomplete(input, options);
}
</script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBvOyp2yb3AAj6AOhelF6GiG52wkVfFGeQ&libraries=places&callback=activatePlacesSearch"></script>

@endsection