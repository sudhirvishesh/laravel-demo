@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    You are logged in! <br>
                    <a  href="#" data-toggle="modal" data-target="#changePassword">Change Password</a>
                    <br>
                    <a  href="#" data-toggle="modal" data-target="#changeName">Change Name</a>
                    <br>
                    <a href="{{ route('service-provider.places.list') }}">Serving Cities</a>
                    <br>
                    <a href="{{ route('service-provider.manage-trucks.list') }}">Manage Trucks</a>
                    <br>
                    <a href="{{ route('service-provider.places.list') }}">Upcoming service Schedule</a>
                    <br>
                    <a href="{{ route('service-provider.places.list') }}">Payments</a>

                </div>
            </div>
        </div>
    </div>
</div>



<div class="modal" id="changePassword">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Change Password</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        
        <div class="modal-body">
        <form id="changePasswordForm" action="{{ url('service-provider/manage-account/change-password') }}" method="post" class="form-horizonttal">
                        @csrf
                        <div id="ab"> </div>
                        <div class="form-group">
                            <label for="">Current Password</label>
                            <input type="password" name="current_password" class="form-control">
                                <span class="invalid-feedback"  role="alert">
                                    <strong id="current_password"></strong>
                                </span>
                        </div>

                        <div class="form-group">
                            <label for="">New Password</label>
                            <input type="password" name="new_password" class="form-control">
                            
                                <span class="invalid-feedback" id="" role="alert">
                                    <strong id="new_password"></strong>
                                </span>
                           
                        </div>

                        <div class="form-group">
                            <label for="">Confirm Password</label>
                            <input type="password" name="new_confirm_password" class="form-control">
                        
                                <span class="invalid-feedback" id="" role="alert">
                                    <strong id="new_confirm_password"></strong>
                                </span>
                        </div>
                        <div id="success"></div>
                        <div class="form-group">
                            <button class="btn btn-success">Change Password</button>
                        </div>
                    </form>        
        </div>
        
       
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>


  <div class="modal" id="changeName">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Change Name</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        
        <div class="modal-body">
        <form id="changeNameForm" action="{{ url('service-provider/manage-account/change-name') }}" method="post" class="form-horizonttal">
                        @csrf

                        
                        <div class="form-group">
                            <label for="">Enter Name</label>
                            <input type="text" name="name" class="form-control">
                                <span class="invalid-feedback"  role="alert">
                                    <strong id="name_msg"></strong>
                                </span>
                        </div>

                        
                        <div id="name_success"></div>
                        <div class="form-group">
                            <button class="btn btn-success">Update</button>
                        </div>
                    </form>        
        </div>
        
       
        <div class="modal-footer">
          <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
  </div>


@endsection

@push('scripts')

<script src="{{ asset('js/manage-account.js') }}" ></script>

@endpush


@push('styles')

<style>

.invalid-feedback {
    display:block;
}
</style>
@endpush