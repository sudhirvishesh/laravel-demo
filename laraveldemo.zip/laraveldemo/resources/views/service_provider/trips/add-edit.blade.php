@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    {{ print_r($errors->all() ) }}
                    <form action="{{ url()->current() }}" class="form-horizontal" enctype="multipart/form-data" method="post">
                        @csrf
                        <div class="form-group">
                            <label for="">Start From</label>
                            <select class="form-control" name="start_from" id="">
                                <option value="">Select</option>
                                @foreach($cities as $city)
                                    <option value="{{ $city->id }}">{{ $city->city }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Destination</label>
                            <select class="form-control" name="destination" id="">
                                <option value="">Select</option>
                                @foreach($cities as $city)
                                    <option value="{{ $city->id }}">{{ $city->city }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Departure Date</label>
                            <input type="date" name="departure_date" class="form-control" id="">
                        </div>

                        <div class="form-group">
                            <label for="">Arrival Date</label>
                            <input type="date" name="arrival_date" class="form-control" id="">
                        </div>

                        <div class="form-group">
                            <label for="">Truck</label>
                            <select class="form-control" name="truck_id" id="">
                                <option value="">Select Truck</option>
                                @foreach($trucks as $truck)
                                    <option value="{{ $truck->id }}">{{ $truck->name }}</option>
                                @endforeach
                            </select>
                            
                        </div>
                        
                        <div class="form-group">
                            <button class="btn btn-success">Save</button>
                        </div>
                        

                    </form>
                   
                </div>
            </div>
        </div>
    </div>
</div>

@endsection