$('#changePasswordForm').submit(function (e) {
    e.preventDefault();
    var url = $('#changePasswordForm').attr('action');
    var formdata = $('#changePasswordForm').serialize();
    var res;
    $.ajax({
        url: url,
        type: "post",
        data: formdata,
        success: function(response){
            if(response.success){
                    $('#success').text(response.success);
                    $("#current_password").text(""); 
                    $("#new_password").text(""); 
                    $("#new_confirm_password").text("");
            }
            else if(response.error) {
                if(response.error.current_password)
                    $("#current_password").text(response.error.current_password[0]);
                else   
                    $("#current_password").text(""); 
                if(response.error.new_password)
                    $("#new_password").text(response.error.new_password[0]); 
                else
                    $("#new_password").text(""); 
                if(response.error.new_confirm_password)
                    $("#new_confirm_password").text(response.error.new_confirm_password[0]);
                else
                    $("#new_confirm_password").text("");
            }
            else {
                
            }
            
        }   
    });

});


$('#changeNameForm').submit(function (e) {
    e.preventDefault();
    var url = $('#changeNameForm').attr('action');
    var formdata = $('#changeNameForm').serialize();
    var res;
    $.ajax({
        url: url,
        type: "post",
        data: formdata,
        success: function(response){
            if(response.success){
                $('#name_success').text(response.success);
                $("#name_msg").text(""); 
            }
            else if(response.error) {
                $("#name_msg").text(response.error.name[0]); 
            }
            else {
                
            }
            
        }   
    });

});