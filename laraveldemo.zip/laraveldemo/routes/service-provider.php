<?php

Route::get('become-service-provider', 'Auth\ServiceProviderApplicationController@index')->name('become-service-provider');
Route::post('become-service-provider', 'Auth\ServiceProviderApplicationController@store');


Route::get('service-provider/profile', function(){
    return view('service_provider.index');
})->name('service-provider.profile')->middleware(['auth', 'role:1']);

