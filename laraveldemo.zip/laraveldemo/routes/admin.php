<?php

use Illuminate\Support\Facades\Route;

Route::prefix('/admin')->name('admin.')->namespace('Admin')->group(function(){
    
    Route::get('login', 'AuthController@showLoginForm')->name('login');
    Route::post('login', 'AuthController@login');
    Route::get('logout', 'AuthController@doLogout')->name('logout');
    Route::post('logout', 'AuthController@logout');

    Route::middleware('auth:admin')->group(function () {
    	
        Route::get('/', 'HomeController@index')->name('home');
        
        //Service Provider Application

        Route::prefix('service-provider')->name('service-provider.')->group( function() {
            Route::get('list', 'ServiceProviderApplicationController@list')->name('list');
            Route::get('show/{key}', 'ServiceProviderApplicationController@show')->name('show');
            Route::post('approve/{key}', 'ServiceProviderApplicationController@approve')->name('approve');
            Route::get('reject/{key}', 'ServiceProviderApplicationController@reject')->name('reject');

        });

 	});

});