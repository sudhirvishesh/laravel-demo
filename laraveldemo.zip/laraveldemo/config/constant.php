<?php

return [
    
    'admin_emails' => [
        'email' => "admin@hidsh.in",
        'name'  => "Admin"
    ],
];